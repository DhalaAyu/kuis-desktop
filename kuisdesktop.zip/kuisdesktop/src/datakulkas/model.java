/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datakulkas;

/**
 *
 * @author ASUS
 */
public class model {
    
    private String harga ;
    private String merk;
    private String stock;
    private String jenis;
    private String tanggal;

    public kulkas(String kode, String harga, String merk, String warna, String stock, String jenis, String tanggal) {
        this.harga = harga;
        this.merk = merk;
        this.tanggal = tanggal;
        this.jenis = jenis;
        this.stock = stock;
    }

    public String getharga() {
        return harga;
    }

    public void setharga(String harga) {
        this.harga = harga;
    }

    public String getmerk() {
        return merk;
    }

    public void setmerk(String merk) {
        this.merk = merk;
    }

    public String gettanggal() {
        return tanggal;
    }

    public void settanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public String getjenis() {
        return jenis;
    }

    public void setjenis(String jenis) {
        this.jenis = jenis;
    }

    public String getstock() {
        return stock;
    }

    public void setstock(String stock) {
        this.stock = stock;
    }
    
}
