/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datakulkas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import sistemakademik.model.Mahasiswa;
/**
 *
 * @author ASUS
 */
public class db {
    
public class db {
    public final Connection conn;

    public db(String driver) {
        this.conn = DBHelper.getConnection(driver);
    }
    public void adddb_kulkas(db_kulkas data kulkas){
        String insertMhs = "INSERT INTO `db_kulkas`(`kode barang`, `merk`, `tanggal`,`warna`,`jenis`,`harga`,`stock`)"
                + "VALUES (?,?,?,?,?)";
        try {
            PreparedStatement stmtInsert = conn.prepareStatement(insertMhs);
            stmtInsert.setString(1, mhs.getkode());
            stmtInsert.setString(2, mhs.getmerk());
            stmtInsert.setString(3, mhs.gettanggal());
            stmtInsert.setString(4, mhs.getwarna());
            stmtInsert.setString(5, mhs.getjenis());
            stmtInsert.setString(6, mhs.getharga());
            stmtInsert.setString(7, mhs.getstock());
            stmtInsert.execute();
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getkode()).log(Level.SEVERE, null, ex);
        }
    }
    
}
}