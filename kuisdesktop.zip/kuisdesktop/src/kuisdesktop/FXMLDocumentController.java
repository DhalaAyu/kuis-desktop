/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuisdesktop;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

/**
 *
 * @author ASUS
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Button buttonsimpan;
    
    @FXML
    private ComboBox<?> cbjenis;

    @FXML
    private TextField tftanggal;

    @FXML
    private RadioButton rdsharp;
    
    @FXML
    private RadioButton rdpolytron;
    
    @FXML
    private RadioButton rdpanasonic;

    @FXML
    private Label label;

    @FXML
    private TextField tfwarna;
    
    @FXML
    private TextField tfharga;

    @FXML
    private TextField tfkode;
    
    }    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
//        label.setText("Hello "+tfkode.getText());
        System.out.println(tfwarna.getText());
        System.out.println(tfharga.getText());
        System.out.println(tftanggal.getText());  
        String merk="";
        if (rdsharp.isSelected())
           merk=rdsharp.getText();
        if (rdpolytron.isSelected())
           merk=rdpolytron.getText();
        if (rdpanasonic.isSelected())
           gender=rdpanasonic.getText();
        
        System.out.println(merk);
        System.out.println(cbjenis.getValue().toString());
//        Kulkas(String kode, String harga, String merk, String warna, String stock, String jenis, String tanggal)
        db_kulkas datakulkas= new data kulkas(tfwarna.getText(),tfharga.getText(),tftanggal.getValue().toString(),
            gender,cbProdi.getValue().toString());
        DBHandler dh = new DBHandler("MYSQL");
        dh.adddb_kulkas(datakulkas);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // TODO
        ArrayList <String> list = new ArrayList<String>();
        list.add("kulkas");
        list.add("kulkas");
        ObservableList items = FXCollections.observableArrayList(list);
        cbProdi.setItems(items);
    }    
    
}